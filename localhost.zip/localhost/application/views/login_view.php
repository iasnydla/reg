
<form action="">
    <label for="login">Логин</label><input type="text" id="login" required><br>
    <label for="password">Пароль</label><input type="password" id="password" required><br>
    <input type="submit" value="Отправить">
</form>