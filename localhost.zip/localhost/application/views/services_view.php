<h1>Услуги</h1>
<p>
Компания <a href="/">ОЛОЛОША TEAM</a> оказывает следующие услуги:
    <?php

    foreach($data as $row)
    {
        echo '<ul><p>'.$row['title'].'</p><li>'.$row['description'].'</li></ul>';
    }

    ?>
</p>