<h1>Админ статьи</h1>
<p>
    <table>
        <tr>
            <td>Название</td>
            <td>Описание</td>
            <td>Редактировать</td>
            <td>Удалить</td>
        </tr>
        <?php foreach($data as $row): ?>
        <tr>
            <td><?=$row['title']?></td>
            <td><?=$row['text']?></td>
            <td><p><a href="/admin_article/edit?id=<?=$row['id']?>" style="color:green">Редактировать</a></p></td>
            <td><p><a href="/admin_article/delete?id=<?=$row['id']?>" style="color:red">Удалить</a></p></td>
        </tr>

<? endforeach; ?>
</table>
</p>