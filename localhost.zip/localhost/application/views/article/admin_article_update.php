<h1>Админ редактирование статьи</h1>
<p>Редактирование</p>
<form action="/admin_article/update" method="post">
    <input type="hidden" name="id" value="<?=$article['id']?>">
    <?php require_once 'form.php';?>
</form>

