<form action="/admin_portfolio/update">
    <?php require_once 'form.php'?>
</form>