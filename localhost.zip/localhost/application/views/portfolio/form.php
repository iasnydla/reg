<p>Год: <input type="text" name="year" id="year" value="<?php ?>"></p>
<p>Проект: <input type="text" name="site" id="site"></p>
<p>Описание: <input type="text" name="description" id="description"></p>
<p><input type="submit" value="Добавить"></p>
