<p>Год: <input type="text" name="year" id="year" value="<?=$portfolio['year']?>"></p>
<p>Проект: <input type="text" name="site" id="site" value="<?=$portfolio['site']?>"></p>
<p>Описание: <input type="text" name="description" id="description" value="<?=$portfolio['description']?>"></p>
<p><input type="submit" value="Отправить"></p>
<
