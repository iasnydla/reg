<h1>Админ редактирование портфолио</h1>
<p>Редактирование</p>
<form action="/admin_portfolio/update" method="post">
    <input type="hidden" name="id" value="<?=$portfolio['id']?>">
<?php require_once 'form.php';?>
</form>

