<h1>Адм_портфолио_Ред</h1>
<p>Редактирование</p>
<form action="/admin_portfolio/update" method="post">
<?php require_once 'form.php';?>
</form>

