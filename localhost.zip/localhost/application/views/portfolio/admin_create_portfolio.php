<form action="/admin_portfolio/store">
   <?php require_once 'form.php'?>
</form>
