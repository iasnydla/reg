<h1>Админ портфолио</h1>
<p>
<table>
    Все проекты в следующей таблице являются вымышленными, поэтому даже не пытайтесь перейти по приведенным ссылкам.
    <tr>
        <td>Год</td>
        <td>Проект</td>
        <td>Описание</td>
        <td>Редактировать</td>
        <td>Удалить</td>
    </tr>
    <?php foreach($data as $row): ?>
    <tr>
        <td><?=$row['year']?></td>
        <td><?=$row['site']?></td>
        <td><?=$row['description']?></td>
        <td><p><a href="/admin_portfolio/edit?id=<?=$row['id']?>" style="color:green">Редактировать</a></p></td>
        <td><p><a href="/admin_portfolio/delete?id=<?=$row['id']?>" style="color:red">Удалить</a></p></td>
    </tr>

    <? endforeach; ?>
</table>

</p>