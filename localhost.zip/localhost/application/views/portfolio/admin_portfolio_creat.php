<h1>Админ создание портфолио</h1>
<form action="/admin_portfolio/store" method="post">
    <?php require_once 'form.php';?>
</form>

