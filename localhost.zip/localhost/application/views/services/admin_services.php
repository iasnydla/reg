<h1>Админ услуги</h1>
<p>
    Компания <a href="/">ОЛОЛОША TEAM</a> оказывает следующие услуги:
        <?php foreach($data as $row): ?>

        <ul><p><?=$row['title']?></p>
        <li><?=$row['description']?></li></ul>
        <td><p><a href="/admin_services/edit?id=<?=$row['id']?>" style="color:olive">Редактировать</a></td></tr>
        <td><p><a href="/admin_services/delete?id=<?=$row['id']?>" style="color:firebrick">Удалить</a></td></tr>
<? endforeach; ?>
</p>