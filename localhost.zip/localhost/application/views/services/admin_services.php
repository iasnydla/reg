<h1>adm Услуги</h1>
<p>
    Компания <a href="/">ОЛОЛОША TEAM</a> оказывает следующие услуги:
    <?php

    foreach($data as $row)
    {
        echo '<ul><p>'.$row['title'].'</p><li>'.$row['description'].'</li></ul>';
        echo '<td><p><a href="/admin_services/delete?id='.$row['id'].'" style="color:red">Удалить</a></td></tr>';
    }

    ?>
</p>