<h1>Админ редактирование услуги</h1>
<p>Редактирование</p>
<form action="/admin_services/update" method="post">
    <input type="hidden" name="id" value="<?=$services['id']?>">
    <?php require_once 'form.php';?>
</form>

