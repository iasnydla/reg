<h1>Адм_Услуги_Ред</h1>
<p>Редактирование</p>
<form action="/admin_services/update" method="post">
    <?php require_once 'form.php';?>
</form>

