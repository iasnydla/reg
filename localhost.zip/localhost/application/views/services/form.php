<p>Название: <input type="text" name="title" id="title" value="<?php ?>"></p>
<p>Описание: <input type="text" name="description" id="description"></p>
<p><input type="submit" value="Добавить"></p>
