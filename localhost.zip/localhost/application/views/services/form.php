<p>Название: <input type="text" name="title" id="title" value="<?=$services['title']?>"></p>
<p>Описание: <input type="text" name="description" id="description" value="<?=$services['description']?>"></p>
<p><input type="submit" value="Отправить"></p>
