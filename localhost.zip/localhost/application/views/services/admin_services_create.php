<h1>Админ создание услуги</h1>
<form action="/admin_services/store" method="post">
    <?php require_once 'form.php';?>
</form>

