<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/application/middleware/AdminMiddleware.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/application/models/model_article.php';

class controller_admin_article extends Controller
{
    function __construct()
    {
        $this->middleware[] = new AdminMiddleware();
        parent::__construct();
        $this->model = new Model_Article();
    }

    function action_index()
    {
        $data = $this->model->get_data();
        $this->view->generate('article/admin_article.php', 'template_view.php', $data);
    }

    function action_create()
    {
        $this->view->generate('article/admin_article_create.php');
    }

    public function action_store()
    {
        $this->model->insert([
            'title'  => $_POST['title'],
            'text'  => $_POST['text'],
        ]);
        redirect('/admin_article');
    }
    function action_delete()
    {
        $this->model->delete($_GET['id']);
        redirect('/admin_article');
    }
    public function action_edit()
    {
        $this->view->generate('article/admin_article_update.php', 'template_view.php',
            ['article'=>$this->model->getById($_GET['id'])]

        );
    }
    public function action_update ()
    {
        $this->model->update($_POST['id'],
            [
                'title'  => $_POST['title'],
                'text'  => $_POST['text'],
            ]
        );
        redirect('/admin_article');
    }
}