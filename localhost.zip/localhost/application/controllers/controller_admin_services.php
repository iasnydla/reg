<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/application/middleware/AdminMiddleware.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/application/models/model_services.php';

class controller_admin_services extends Controller
{
    function __construct()
    {
        $this->middleware[] = new AdminMiddleware();
        parent::__construct();
        $this->model = new Model_Services();
    }

    function action_index()
    {
        $data = $this->model->get_data();
        $this->view->generate('services/admin_services.php', 'template_view.php', $data);
    }

    function action_create()
    {
        $this->view->generate('services/admin_services_create.php');
    }

    public function action_store()
    {
        $this->model->insert([
            'title'  => $_POST['title'],
            'description'  => $_POST['description'],
        ]);
        redirect('services/admin_services');
    }
    function action_delete()
    {
        $this->model->delete($_GET['id']);
        redirect('services/admin_services');
    }
    public function action_edit()
    {
        $data = $this->model->getById($_GET['id']);
        echo '<pre>';
        var_dump($data);
    }
}