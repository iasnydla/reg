<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/application/services/UserService.php';
require_once  'Middleware.php';
class AdminMiddleware implements Middleware
{
    public function handle():bool
    {
        $userService = new UserService();
        return $userService->isAuth();
    }
}