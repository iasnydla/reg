<?php

interface Middleware
{

    public function handle():bool;

}