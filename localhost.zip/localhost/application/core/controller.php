<?php

class Controller {
	
	public $model;
	public $view;
    /**
     * @var Middleware array
     */
	public $middlewares = [];
	function __construct()
	{
		$this->view = new View();
		$this->checkMiddleware();
	}
	private function checkMiddleware()
    {
        /** @var Middleware $middleware */
        foreach ($this->middlewares as $middleware) {
            if (!$middleware->handle()) {
                Route::ErrorPage404();
            }
        }
    }
	// действие (action), вызываемое по умолчанию
	function action_index()
	{
		// todo	
	}
}
