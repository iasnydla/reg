<?php

class Model_Article extends Model
{

    public $table = 'article';

    public function get_data()
    {
        return $this->get();
    }

}

