<?php
    if ($_POST['submit']) {
            require_once 'db.php';
            $apply_mail = false;
            $apply_login = false;
            $apply_password = false;
            if (trim($_POST['fio']) == '' || trim($_POST['date_born']) == '' || trim($_POST['mail']) == '' || trim($_POST['login']) == '' || trim($_POST['password']) == '' || trim($_POST['password_apply']) == '') {
                header("Refresh: 5");
                echo 'Не все поля заполнены!<br>Вы будете перенаправлены, через 5 секунд';
            }
            else {
                $stmt = $pdo->prepare("SELECT `mail` FROM `users` WHERE `mail` = :mail");
                $stmt->execute(array(
                    'mail' => $_POST['mail']
                ));
                $data = $stmt->fetchAll();
                if (empty($data)) $apply_mail = true;
                else {
                    header("refresh: 5");
                    echo 'Пользователь с таким E-mail уже существует!<br>Вы будете перенаправлены, через 5 секунд';
                    exit();
                }
                $stmt = $pdo->prepare("SELECT `login` FROM `users` WHERE `login` = :login");
                $stmt->execute(array(
                    'login' => $_POST['login']
                ));
                $data = $stmt->fetchAll();
                if (empty($data)) $apply_login = true;
                else {
                    header("refresh: 5");
                    echo 'Пользователь с таким логином уже существует!<br>Вы будете перенаправлены, через 5 секунд';
                    exit();
                }
                if ($_POST['password'] != $_POST['password_apply']) {
                    header("refresh: 5");
                    echo 'Пароли не совпадают!<br>Вы будете перенаправлены, через 5 секунд';
                    $apply_password = false;
                    exit();
                }
                else $apply_password = true;
                if ($apply_mail == true && $apply_login == true && $apply_password == true) {
                    $stmt = $pdo->prepare("INSERT INTO `users` SET `fio` = :fio, `date_born` = :born, `mail` = :mail, `login` = :login, `password` = :password");
                    $stmt->execute(array(
                        'fio' => $_POST['fio'], 
                        'born' => date("Y-m-d", strtotime($_POST['date_born'])),
                        'mail' => $_POST['mail'],
                        'login' => $_POST['login'],
                        'password' => $_POST['password']
                    ));
                    header("refresh: 5");
                    echo 'Регистрация прошла успешно!<br>Вы будете перенаправлены, через 5 секунд';
                }

            }
    } else {
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Регистрация</title>
</head>
<body>
    <form method="POST" action="index.php">
        <input type="text" placeholder="ФИО" name="fio">
        <input type="text" placeholder="Дата рождения" name="date_born">
        <input type="text" placeholder="E-mail" name="mail">
        <input type="text" placeholder="Логин" name="login">
        <input type="text" placeholder="Пароль" name="password">
        <input type="text" placeholder="Подтверждение пароля" name="password_apply">
        <input type="submit" value="Отправить" name="submit">
        <a href="auth.php">Уже зарегистрирован</a>
    </form>
</body>
</html>
<?php } ?>