<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/application/middleware/AdminMiddleware.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/application/models/model_portfolio.php';
class Controller_Admin_Portfolio extends Controller {
    function __construct()
    {
        $this->middlewares[] = new AdminMiddleware();
        parent::__construct();
        $this->model = new Model_Portfolio();
    }

    public function action_index()
    {
        $data=$this->model->get_data();
        $this->view->generate('portfolio_view.php', 'template_view.php', $data);
    }

    function action_create()
    {
        $this->view->generate('admin_portfolio_view.php', 'template_view.php');
    }

    public function action_store(){
        $model = new Model_Portfolio();
        $model->insert([
            'site'=>$_POST['site'],
            'year'=>$_POST['year'],
            'description'=>$_POST['description']
        ]);
    }
}