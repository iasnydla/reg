
<h1>Портфолио</h1>
<form action="/admin_portfolio/store" method="post">
    <input type="text" name="year" placeholder="year">
    <input type="text" name="site" placeholder="site">
    <input type="text" name="description" placeholder="description">
    <input type="submit" name="send">
</form>
