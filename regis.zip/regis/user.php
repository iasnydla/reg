<?php
session_start();
    if ($_SESSION['user_id']) {
        require_once 'db.php'; 
        $stmt = $pdo->prepare("SELECT `id`, `fio`, `date_born`, `login`, `mail` FROM `users` WHERE `id` = :id");
        $stmt->execute(array(
            'id' => $_SESSION['user_id']
        ));
        $data = $stmt->fetchAll();
        ?>
        <!DOCTYPE html>
        <html lang="ru">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="X-UA-Compatible" content="ie=edge">
            <title>Личный кабинет</title>
        </head>
        <body>
            <?php 
                foreach($data as $x) {
                    echo 'ФИО: '.$x['fio'];
                    echo 'Дата рождения: '.$x['date_born'];
                    echo 'Логин: '.$x['login'];
                    echo 'Почта: '.$x['mail'];
                }
            ?>
        </body>
        </html>
<?php
    } else {
        header("Refresh: 0, url=/regis");
    }
?>
