<?php
    if ($_POST['submit']) {
        require_once 'db.php';
        if (trim($_POST['login']) == '' || trim($_POST['password']) == '') {
            header("Refresh: 5");
            echo 'Не все поля заполнены!<br>Вы будете перенаправлены, через 5 секунд';
        }
        else {
            $stmt = $pdo->prepare("SELECT `login` FROM `users` WHERE `login` = :login");
            $stmt->execute(array(
                'login' => $_POST['login']
            ));
            $data = $stmt->fetchAll();
            if (!empty($data)) {
                $stmt = $pdo->prepare("SELECT `id`, `login`, `password` FROM `users` WHERE `login` = :login AND `password` = :password");
                $stmt->execute(array(
                    'login' => $_POST['login'], 
                    'password' => $_POST['password']
                ));
                $data = $stmt->fetchAll();
                if (!empty($data)) {
                    session_start();
                    $_SESSION['user_id'] = $data[0]['id'];
                    header("Refresh: 0, url=user.php");
                }
                else {
                    header("Refresh: 5");
                    echo 'Неверный пароль!<br>Вы будете перенаправлены, через 5 секунд';
                }
            }
            else {
                header("Refresh: 5");
                echo 'Пользователя не существует!<br>Вы будете перенаправлены, через 5 секунд';
            }
        }
    } else {
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Авторизация</title>
</head>
<body>
    <form method="POST" action="auth.php">
        <input type="text" placeholder="Логин" name="login">
        <input type="text" placeholder="Пароль" name="password">
        <input type="submit" value="Войти" name="submit">
        <a href="/regis">Регистрация</a>
    </form>
</body>
</html>
<?php } ?>